"use client";

import { useState, type FormEvent } from "react";
import { BRAND, LINKS } from "@/config/brand";
import type { Copy } from "@/lib/i18n";
import { BrandLogo } from "@/components/ui/BrandLogo";
import { EyeIcon, EyeOffIcon, LockIcon, SignInIcon, UserIcon } from "@/components/ui/Icons";
import { TextField } from "@/components/ui/TextField";

export function LoginCard({ t }: { t: Copy }) {
  const [showPassword, setShowPassword] = useState(false);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    // Phase 1 is UI only: authentication is intentionally not implemented yet.
  }

  return (
    <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-[0_24px_60px_-28px_rgba(77,20,41,0.35)] ring-1 ring-burgundy-100 sm:p-9">
      <div className="flex items-center gap-3">
        <BrandLogo size={52} />
        <div>
          <p lang="ar" className="text-2xl leading-tight font-bold text-burgundy-800">
            {BRAND.ar.name}
          </p>
          <p lang="en" className="mt-0.5 text-sm font-semibold text-ink-700">
            {BRAND.en.name}
          </p>
        </div>
      </div>

      <h1 className="mt-8 text-2xl font-bold text-ink-900 sm:text-[1.75rem]">{t.title}</h1>
      <p className="mt-1 text-ink-600">{t.subtitle}</p>

      <form onSubmit={handleSubmit} className="mt-7 space-y-5">
        <TextField
          id="username"
          name="username"
          label={t.idLabel}
          placeholder={t.idPlaceholder}
          icon={<UserIcon className="size-5" />}
          autoComplete="username"
          autoCapitalize="none"
          spellCheck={false}
          required
        />

        <TextField
          id="password"
          name="password"
          type={showPassword ? "text" : "password"}
          label={t.passwordLabel}
          placeholder={t.passwordPlaceholder}
          icon={<LockIcon className="size-5" />}
          autoComplete="current-password"
          required
          trailing={
            <button
              type="button"
              onClick={() => setShowPassword((visible) => !visible)}
              aria-label={t.showPassword}
              aria-pressed={showPassword}
              className="grid size-9 place-items-center rounded-lg text-ink-400 transition-colors hover:text-ink-700 focus-visible:outline-2 focus-visible:outline-burgundy-600"
            >
              {showPassword ? <EyeOffIcon className="size-5" /> : <EyeIcon className="size-5" />}
            </button>
          }
        />

        <div className="flex items-center justify-between gap-4">
          <label className="flex items-center gap-2.5 text-sm text-ink-700 select-none">
            <input
              type="checkbox"
              name="remember"
              className="size-4 rounded border-ink-300 accent-burgundy-600"
            />
            {t.remember}
          </label>
          <a
            href={LINKS.forgotPassword}
            className="rounded text-sm font-medium text-burgundy-600 underline-offset-4 hover:text-burgundy-700 hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-burgundy-600"
          >
            {t.forgotPassword}
          </a>
        </div>

        <button
          type="submit"
          className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-burgundy-600 text-base font-semibold text-white shadow-sm transition-colors hover:bg-burgundy-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-burgundy-600"
        >
          <SignInIcon className="size-5 rtl:-scale-x-100" />
          {t.signIn}
        </button>
      </form>

      <div className="mt-7 border-t border-ink-100 pt-5 text-center">
        <a
          href={LINKS.support}
          className="rounded text-sm font-medium text-burgundy-600 underline-offset-4 hover:text-burgundy-700 hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-burgundy-600"
        >
          {t.contactSupport}
        </a>
      </div>
    </div>
  );
}
