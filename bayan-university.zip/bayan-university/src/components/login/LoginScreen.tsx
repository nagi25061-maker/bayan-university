"use client";

import { useState } from "react";
import { copy, dirOf, LANG_COOKIE, type Locale } from "@/lib/i18n";
import { HeroPanel } from "./HeroPanel";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { LoginCard } from "./LoginCard";

const ONE_YEAR = 60 * 60 * 24 * 365;

export function LoginScreen({ initialLocale }: { initialLocale: Locale }) {
  const [locale, setLocale] = useState<Locale>(initialLocale);
  const t = copy[locale];

  function changeLocale(next: Locale) {
    setLocale(next);
    document.documentElement.lang = next;
    document.documentElement.dir = dirOf(next);
    document.cookie = `${LANG_COOKIE}=${next}; path=/; max-age=${ONE_YEAR}; samesite=lax`;
  }

  return (
    <main className="relative min-h-dvh lg:grid lg:grid-cols-[minmax(0,1fr)_minmax(28rem,36rem)]">
      <div className="absolute end-4 top-4 z-20 lg:end-6 lg:top-6">
        <LanguageSwitcher locale={locale} label={t.languageLabel} onChange={changeLocale} />
      </div>

      <HeroPanel locale={locale} t={t} />

      <section className="relative -mt-6 flex items-start justify-center rounded-t-3xl bg-burgundy-50 px-4 pt-8 pb-10 sm:px-8 lg:mt-0 lg:items-center lg:rounded-none lg:px-8 lg:py-12">
        <LoginCard t={t} />
      </section>
    </main>
  );
}
