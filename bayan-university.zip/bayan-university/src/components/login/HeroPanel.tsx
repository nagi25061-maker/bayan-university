import Image from "next/image";
import type { ComponentType, SVGProps } from "react";
import { BRAND } from "@/config/brand";
import { cn } from "@/lib/cn";
import type { Copy, FeatureKey, Locale } from "@/lib/i18n";
import { BrandLogo } from "@/components/ui/BrandLogo";
import {
  FileTextIcon,
  GraduationCapIcon,
  TrendingUpIcon,
  UsersIcon,
} from "@/components/ui/Icons";

const FEATURE_ICONS: Record<FeatureKey, ComponentType<SVGProps<SVGSVGElement>>> = {
  courses: GraduationCapIcon,
  updates: FileTextIcon,
  progress: TrendingUpIcon,
  future: UsersIcon,
};

interface HeroPanelProps {
  locale: Locale;
  t: Copy;
}

export function HeroPanel({ locale, t }: HeroPanelProps) {
  const other: Locale = locale === "en" ? "ar" : "en";
  const primary = BRAND[locale];
  const secondary = BRAND[other];

  return (
    <section className="relative isolate h-72 overflow-hidden bg-burgundy-900 sm:h-80 lg:h-auto lg:min-h-dvh">
      <Image
        src={BRAND.campusSrc}
        alt=""
        fill
        priority
        sizes="(min-width: 1024px) 64vw, 100vw"
        unoptimized={BRAND.campusSrc.endsWith(".svg")}
        className="-z-20 object-cover"
      />
      {/* Overlay: darkens the lower area behind the welcome text, keeps the sky readable. */}
      <div
        aria-hidden="true"
        className="absolute inset-0 -z-10 bg-linear-to-t from-black/75 via-black/25 to-black/10"
      />

      <div className="flex h-full flex-col justify-between p-5 pb-10 sm:p-8 sm:pb-12 lg:p-12">
        <header className="flex items-start justify-between gap-6 pe-28 sm:pe-32 lg:pe-0">
          <div className="flex items-center gap-3" lang={locale}>
            <BrandLogo variant="badge" size={48} />
            <div className="text-white">
              <p
                className={cn(
                  "leading-tight font-bold",
                  locale === "en" ? "text-lg sm:text-xl" : "text-xl sm:text-2xl",
                )}
              >
                {primary.name}
              </p>
              <p className="mt-0.5 text-sm text-white/80">{primary.tagline}</p>
            </div>
          </div>

          <div className="hidden text-end text-white lg:block" lang={other}>
            <p className={cn("leading-tight font-bold", other === "ar" ? "text-2xl" : "text-xl")}>
              {secondary.name}
            </p>
            <p className="mt-0.5 text-sm text-white/80">{secondary.tagline}</p>
          </div>
        </header>

        <div>
          <p className="text-2xl leading-tight font-light text-white sm:text-3xl lg:text-5xl">
            {t.heroLead}
          </p>
          <p className="mt-1 text-3xl leading-tight font-bold text-white sm:text-4xl lg:text-5xl">
            {t.heroName}
          </p>
          <p className="mt-3 text-sm text-white/85 sm:text-base lg:text-lg">{t.heroSubtitle}</p>

          <ul className="mt-10 hidden grid-cols-2 gap-x-6 gap-y-6 lg:grid xl:grid-cols-4 xl:gap-x-0">
            {t.features.map((feature) => {
              const FeatureIcon = FEATURE_ICONS[feature.key];
              return (
                <li
                  key={feature.key}
                  className="text-white xl:border-s xl:border-white/20 xl:ps-5 xl:first:border-s-0 xl:first:ps-0"
                >
                  <FeatureIcon className="size-6 text-burgundy-200" />
                  <p className="mt-2 text-sm font-semibold">{feature.title}</p>
                  <p className="mt-0.5 text-xs text-white/70">{feature.caption}</p>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </section>
  );
}
