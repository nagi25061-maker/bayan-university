import { cn } from "@/lib/cn";
import type { Locale } from "@/lib/i18n";
import { GlobeIcon } from "@/components/ui/Icons";

const OPTIONS: { locale: Locale; label: string }[] = [
  { locale: "en", label: "EN" },
  { locale: "ar", label: "عربي" },
];

interface LanguageSwitcherProps {
  locale: Locale;
  label: string;
  onChange: (locale: Locale) => void;
}

/** Floats over the photo on mobile (light-on-dark) and over the light panel on desktop. */
export function LanguageSwitcher({ locale, label, onChange }: LanguageSwitcherProps) {
  return (
    <div
      role="group"
      aria-label={label}
      className={cn(
        "inline-flex items-center rounded-full p-0.5 text-sm",
        "bg-black/35 backdrop-blur-sm",
        "lg:bg-white lg:shadow-sm lg:ring-1 lg:ring-ink-200 lg:backdrop-blur-none",
      )}
    >
      <GlobeIcon className="mx-2 size-4 text-white/80 lg:text-ink-400" />
      {OPTIONS.map((option) => {
        const active = option.locale === locale;
        return (
          <button
            key={option.locale}
            type="button"
            lang={option.locale}
            aria-pressed={active}
            onClick={() => onChange(option.locale)}
            className={cn(
              "rounded-full px-3 py-2 leading-none font-medium transition-colors",
              "focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-burgundy-500",
              active
                ? "bg-white text-burgundy-700 lg:bg-burgundy-600 lg:text-white"
                : "text-white/85 hover:text-white lg:text-ink-600 lg:hover:text-ink-900",
            )}
          >
            {option.label}
          </button>
        );
      })}
    </div>
  );
}
