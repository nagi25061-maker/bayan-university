import type { InputHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/cn";

interface TextFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "id" | "className"> {
  id: string;
  label: string;
  icon: ReactNode;
  /** Optional control rendered at the end of the field (e.g. password visibility toggle). */
  trailing?: ReactNode;
}

export function TextField({ id, label, icon, trailing, ...inputProps }: TextFieldProps) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-ink-800">
        {label}
      </label>
      <div className="relative">
        <span
          aria-hidden="true"
          className="pointer-events-none absolute inset-y-0 start-3.5 flex items-center text-ink-400"
        >
          {icon}
        </span>
        <input
          id={id}
          className={cn(
            "h-12 w-full rounded-xl border border-ink-200 bg-white ps-11 text-base text-ink-900",
            "placeholder:text-ink-400 hover:border-ink-300",
            "focus:border-burgundy-500 focus:ring-4 focus:ring-burgundy-500/15 focus:outline-none",
            "transition-colors",
            trailing ? "pe-12" : "pe-4",
          )}
          {...inputProps}
        />
        {trailing ? (
          <div className="absolute inset-y-0 end-1.5 flex items-center">{trailing}</div>
        ) : null}
      </div>
    </div>
  );
}
