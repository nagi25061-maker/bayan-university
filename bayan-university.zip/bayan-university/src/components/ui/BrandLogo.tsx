import Image from "next/image";
import { BRAND } from "@/config/brand";
import { cn } from "@/lib/cn";

interface BrandLogoProps {
  size?: number;
  /** "badge" puts the mark on a white tile so it stays legible over photography. */
  variant?: "plain" | "badge";
  className?: string;
}

export function BrandLogo({ size = 56, variant = "plain", className }: BrandLogoProps) {
  const image = (
    <Image
      src={BRAND.logoSrc}
      alt=""
      width={size}
      height={size}
      unoptimized={BRAND.logoSrc.endsWith(".svg")}
      className="block"
    />
  );

  if (variant === "plain") return <span className={cn("shrink-0", className)}>{image}</span>;

  return (
    <span className={cn("shrink-0 rounded-2xl bg-white p-1.5 shadow-sm", className)}>{image}</span>
  );
}
