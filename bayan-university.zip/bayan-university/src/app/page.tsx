import { LoginScreen } from "@/components/login/LoginScreen";
import { getLocale } from "@/lib/get-locale";

export default async function Page() {
  return <LoginScreen initialLocale={await getLocale()} />;
}
