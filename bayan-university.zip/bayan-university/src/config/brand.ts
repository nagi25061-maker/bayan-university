/**
 * Single place for brand identity and replaceable assets.
 * To use the real campus photo / logo: drop the files into /public and change the paths below.
 */
export const BRAND = {
  en: { name: "BAYAN UNIVERSITY", tagline: "Knowledge • Skills • Future" },
  ar: { name: "جامعة البيان", tagline: "بالعلم نبني المستقبل" },
  /** Placeholder – replace with the official logo (SVG or PNG, square works best). */
  logoSrc: "/brand/logo-placeholder.svg",
  /** Placeholder – replace with e.g. "/images/campus.jpg" (landscape, ≥1920px wide). */
  campusSrc: "/images/campus-placeholder.svg",
} as const;

/** Phase 1 placeholders; point these at real routes once they exist. */
export const LINKS = {
  forgotPassword: "#",
  support: "#",
} as const;
