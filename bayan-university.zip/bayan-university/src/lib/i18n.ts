export const LOCALES = ["en", "ar"] as const;
export type Locale = (typeof LOCALES)[number];

export const DEFAULT_LOCALE: Locale = "en";
export const LANG_COOKIE = "bayan-lang";

export function isLocale(value: unknown): value is Locale {
  return typeof value === "string" && (LOCALES as readonly string[]).includes(value);
}

export function dirOf(locale: Locale): "ltr" | "rtl" {
  return locale === "ar" ? "rtl" : "ltr";
}

export type FeatureKey = "courses" | "updates" | "progress" | "future";

export interface Copy {
  heroLead: string;
  heroName: string;
  heroSubtitle: string;
  features: { key: FeatureKey; title: string; caption: string }[];
  title: string;
  subtitle: string;
  idLabel: string;
  idPlaceholder: string;
  passwordLabel: string;
  passwordPlaceholder: string;
  showPassword: string;
  remember: string;
  forgotPassword: string;
  signIn: string;
  contactSupport: string;
  languageLabel: string;
}

export const copy: Record<Locale, Copy> = {
  en: {
    heroLead: "Welcome to",
    heroName: "Bayan University",
    heroSubtitle: "Your academic journey starts here",
    features: [
      { key: "courses", title: "Access Courses", caption: "Your learning materials" },
      { key: "updates", title: "Stay Updated", caption: "Latest announcements" },
      { key: "progress", title: "Track Progress", caption: "Your academic journey" },
      { key: "future", title: "Build Your Future", caption: "With Bayan University" },
    ],
    title: "Welcome Back!",
    subtitle: "Sign in to your university account",
    idLabel: "University ID or Username",
    idPlaceholder: "Enter your ID or username",
    passwordLabel: "Password",
    passwordPlaceholder: "Enter your password",
    showPassword: "Show password",
    remember: "Remember me",
    forgotPassword: "Forgot Password?",
    signIn: "Sign In",
    contactSupport: "Contact Support",
    languageLabel: "Language",
  },
  ar: {
    heroLead: "مرحبًا بكم في",
    heroName: "جامعة البيان",
    heroSubtitle: "رحلتك الأكاديمية تبدأ من هنا",
    features: [
      { key: "courses", title: "المقررات الدراسية", caption: "موادك التعليمية" },
      { key: "updates", title: "ابقَ على اطلاع", caption: "آخر الإعلانات" },
      { key: "progress", title: "تابع تقدمك", caption: "مسيرتك الأكاديمية" },
      { key: "future", title: "ابنِ مستقبلك", caption: "مع جامعة البيان" },
    ],
    title: "مرحبًا بعودتك!",
    subtitle: "سجّل الدخول إلى حسابك الجامعي",
    idLabel: "الرقم الجامعي أو اسم المستخدم",
    idPlaceholder: "أدخل الرقم الجامعي أو اسم المستخدم",
    passwordLabel: "كلمة المرور",
    passwordPlaceholder: "أدخل كلمة المرور",
    showPassword: "إظهار كلمة المرور",
    remember: "تذكّرني",
    forgotPassword: "نسيت كلمة المرور؟",
    signIn: "تسجيل الدخول",
    contactSupport: "التواصل مع الدعم",
    languageLabel: "اللغة",
  },
};
